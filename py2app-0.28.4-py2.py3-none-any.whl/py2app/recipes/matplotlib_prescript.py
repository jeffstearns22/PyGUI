import os

os.environ["MATPLOTLIBDATA"] = os.path.join(os.environ["RESOURCEPATH"], "mpl-data")
